GOLDEN TRADING COMPANY WEBSITE

Files:
- index.html — complete responsive website.

To publish free:
1. Create a free GitHub account.
2. Create a new public repository, for example: golden-trading-company.
3. Upload index.html.
4. Go to Settings -> Pages -> Deploy from branch -> main -> / (root).
5. GitHub will give you a free pages address.

For www.goldentc.com:
- You need to own the domain and set its DNS records to GitHub Pages.
- GitHub Pages hosting itself is free; the custom domain registration is normally paid.
